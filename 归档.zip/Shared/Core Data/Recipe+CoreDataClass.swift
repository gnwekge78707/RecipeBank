//
//  Recipe+CoreDataClass.swift
//  Recipe-Builder
//
//  Created by Jake Davies on 24/06/2021.
//
//

import Foundation
import CoreData

@objc(Recipe)
public class Recipe: NSManagedObject {
    
}
