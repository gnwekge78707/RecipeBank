# Privacy Policy

Jake Davies built the Recipe Builder app as an Open Source app. This SERVICE is provided by Jake Davies at no cost and is intended for use as is.

This page is used to inform visitors regarding my policies with the collection, use, and disclosure of Personal Information if anyone decided to use my Service.

If you choose to use my Service, then you agree to the collection and use of information in relation to this policy. The Personal Information that I collect is used for providing and improving the Service. I will not use or share your information with anyone except as described in this Privacy Policy.

To summarise this policy for our users, the Recipe Builder app collects no personal data about our users. It does interface with iCloud in order to allow data to be synced across users' devices, however we do not collect or store any of the personal data associated with this ourselves.

**Information Collection and Use**

The app does use third party services that may collect information used to identify you.

Link to privacy policy of third party service providers used by the app

*   [Apple Privacy Policy](https://www.apple.com/uk/legal/privacy/en-ww/)

**Log Data**

I want to inform you that whenever you use my Service, in a case of an error in the app I collect data and information (through third party products) on your phone called Log Data. This Log Data may include information such as your device Internet Protocol (“IP”) address, device name, operating system version, the configuration of the app when utilizing my Service, the time and date of your use of the Service, and other statistics.

**Service Providers**

I may employ third-party companies and individuals due to the following reasons:

*   To facilitate our Service;
*   To provide the Service on our behalf;
*   To perform Service-related services; or
*   To assist us in analyzing how our Service is used.

I want to inform users of this Service that these third parties have access to your Personal Information. The reason is to perform the tasks assigned to them on our behalf. However, they are obligated not to disclose or use the information for any other purpose.

**Security**

I value your trust in providing us your Personal Information, thus we are striving to use commercially acceptable means of protecting it. But remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable, and I cannot guarantee its absolute security.

**Changes to This Privacy Policy**

I may update our Privacy Policy from time to time. Thus, you are advised to review this page periodically for any changes. I will notify you of any changes by posting the new Privacy Policy on this page.

This policy is effective as of 2021-07-17

**Contact Us**

If you have any questions or suggestions about my Privacy Policy, do not hesitate to contact me at jakedves@gmail.com.
